<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" constent="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Sistem Informasi PKL di PT. Maju Terus</title>
    <style>
        body {
            font-family : Arial, sans-serif;
            padding : 0;
            margin : 0;
            background-color:#f4f4f4;
        }    
        header, footer {
            background-color: #A6CDC6;
            color:white;
            text-align: center;
            padding: 10px 0;
        }
        nav {
            background-color: #16404D;
            padding: 10px;
            text-align: center;
        }
        nav a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        #content {
            padding: 20px;
        }
        iframe {
            width: 100%;
            height: 667px;
            border: none;
        }
    </style>
</head>
<body>
    <!-- Include Header -->
    <?php Include 'header.php'; ?>

    <!-- Include Header -->
    <?php Include 'menu.php'; ?>

    <!-- Include Header -->
    <div id="content">
    <iframe name="contentFrame" src="crud/home.php"></iframe>
    </div>

    <!-- Include Header -->
    <?php Include 'footer.php'; ?>
</body>
</html>
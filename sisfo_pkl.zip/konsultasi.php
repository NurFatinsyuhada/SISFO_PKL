<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Halaman Konsultasi</title>
</head>
<body>
    <div class="chat-container">
        <h2>Konsultasi</h2>
        <div class="chat-box" id="chat-box">
            <!-- Pesan Akan Munsul Di sini -->
        </div>
        <input type="text" id="chatInput" class="chat-input"
        placeholder="Tulis Pesan...">
        <button onclick="sendMessage()">Kirim</button>
    </div>

    <script>
        function sendMessage(){
            const chatInput = document.getElementById('chatInput');
            const chatBox = document.getElementById('chatBox');
            const message = chatInput.value.trim();

            if(message) {
            // Tambahkan pesan pengguna ke chatBox
            const userMessage = document.createElemen('div');
            userMessage.className = 'message user';
            userMessage.innerText = message;
            chatBox.appendChild(userMessage);

            // Simulasi belasan admin (bisa diganti dengan backend handling)
            const adminMessage = document.createElement('div');
            adminMessage.className = 'message admin';
            adminMessage.innerText = 'Admin: Terima kasih, Pesan Anda telah diterima.';
            chatBox.appendChild(adminMessage);

            //Scroll kebagian bawah chat
            chatBox.scrollTop = chatBox.scrollHeight;

            //Bersihkaninput
            chatInput.value = '';
            }
        }
    </script>
</body>
</html>